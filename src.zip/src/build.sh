cd /home/gw/opensource/quiche;./build.sh;
cd -;
cc client.c -o client  -I../include -L../home/gw/opensource/quiche/target/debug -L../libs   -lquiche -lcrypto -lssl -lev -lpthread  -ldl
cc server.c -o server  -I../include -L../home/gw/opensource/quiche/target/debug -L../libs  -lquiche -lcrypto -lssl -lev  -lpthread -ldl
