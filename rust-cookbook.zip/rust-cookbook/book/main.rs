fn main() {
    println!("This program does nothing.");
    println!("See documentation at https://github.com/rust-lang-nursery/rust-cookbook");
}
