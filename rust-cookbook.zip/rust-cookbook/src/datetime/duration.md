# Duration and Calculation

{{#include duration/profile.md}}

{{#include duration/checked.md}}

{{#include duration/timezone.md}}

{{#include ../links.md}}
