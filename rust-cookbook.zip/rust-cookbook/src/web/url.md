# Uniform Resource Location

{{#include url/parse.md}}

{{#include url/base.md}}

{{#include url/new.md}}

{{#include url/origin.md}}

{{#include url/fragment.md}}

{{#include ../links.md}}
