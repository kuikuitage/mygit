[Frontend-0]: TS Unlock!...
X
the memsize parsed from cmdline is 64M.
Partition Version :  102
Partition Count   :  11
Write Protect     :  FALSE
CRC32 Enable      :  FALSE
Table CRC32       :  52C5DD9F
==============================================================================================
ID NAME    FS      CRC32     START    TOTAL_SIZE   MAIN_SIZE  USED_SIZE      Use%  RES_SIZE
==============================================================================================
0  BOOT    RAW     CA4812D7  00000000      64 KB      64 KB   55848  B      85%       0 MB
1  TABLE   RAW               00010000      64 KB      64 KB       0 MB       0%       0 MB
2  AC3     RAW               00020000      64 KB      64 KB       0 MB       0%       0 MB
3  LOGO    RAW     75B4A92A  00030000     128 KB     128 KB  126676  B      96%       0 MB
4  CAUSER  RAW     B4A426D5  00050000      64 KB      64 KB      33  B       0%       0 MB
5  I_OEM   RAW     86BA7339  00060000      64 KB      64 KB     187  B       0%       0 MB
6  V_OEM   RAW     122987F7  00070000      64 KB      64 KB     580  B       0%       0 MB
7  OTA     RAW     DE70E6CD  00080000     192 KB     192 KB     183 KB      95%       0 MB
8  KERNEL  RAW     95BF924E  000b0000       3 MB       3 MB    2175 KB      70%       0 MB
9  ROOT    CRAMFS  A62C212D  003b0000    2368 KB    2368 KB    1576 KB      66%       0 MB
10 DATA    MINIFS  FF000000  00600000       2 MB       2 MB       1  B       0%       0 MB
----------------------------------------------------------------------------------------------


GxLoader v1.9 20140509 

cpu family	: CSKY
chip model	: gx3113C
board type	: ddr2
memory size	: 64 MB
Flash type	: mx25l64
Flash size	: 8 MB
cpu freq	: 432 MHz
memory freq	: 300 MHz
please press keyboard
pflag=0, will not enter ota.
error: ypbyr_hdmi mode not support. please modify .config to enable it. 
show jpeg logo ...
romfs_load file ecos.bin.gz.

Decompress kernel ...ok
The total boot time is: 2 s (2775 ms)
bootloader_tags detect: 0x9100ca3c.
cmdline str: mem=35M videomem=16M fbmem=13M console=ttyS0,115200 init=/init root=/dev/mtdblock9 mtdparts=m25p80:64k@0m(BOOT),64k@64k(TABLE),64k@128k(AC3),128k@192k(LOGO),64k@320k(CAUSER),64k@384k(I_OEM),64k@448k(V_OEM),192k@512k(OTA),3m@704k(KERNEL),2368k@3776k(ROOT),2.
mem_info bank[0]start:90000000, size:2300000.
mem_info bank[1]start:92300000, size:1d00000.
The whole mem size: 4000000.
dynamic device '/dev/gxpanel0' init error 
jedec_id=c22017, ext_id=c220
USB HCD: device gx-ehci, build at  09:41:58 May 27 2015 
ehci: 0x905b838c
ehci->hcs_params=0x1111, num: 1
hcs_params=0x1111
flag=0x0.
hub1=0x2000
hub2=0x0
ehci base=0xa0900000
operational base= 0xa0900010
gx-ehci gx-ehci.0: gx EHCI
gx-ehci gx-ehci.0: new USB bus registered, assigned bus number 1
ehci_mem_init():ehci->async->qh_dma=0x105c48e0
ehci_mem_init():sizeof qtd: 96.
ehci_mem_init():sizeof qh: 128.
gx-ehci gx-ehci.0: supports USB remote wakeup
gx-ehci gx-ehci.0: irq 59, io mem 0xa0900000
usb usb1: default language 0x0409
usb usb1: new device strings: Mfr=3, Product=2, SerialNumber=1
usb usb1: usb_probe_device
usb usb1: configuration #1 chosen from 1 choice
usb usb1: adding 1-:1.0 (config #1, interface 0)
hub 1-:1.0: usb_probe_interface
hub 1-:1.0: usb_probe_interface - got id
hub 1-:1.0: USB hub found
hub 1-:1.0: 1 port detected
hub 1-:1.0: standalone hub
hub 1-:1.0: individual port power switching
hub 1-:1.0: individual port over-current protection
hub 1-:1.0: Single TT
hub 1-:1.0: TT requires at most 8 FS bit times (666 ns)
hub 1-:1.0: power on to power good time: 20ms
hub 1-:1.0: local power source is good
hub 1-:1.0: enabling power on all ports
USB HCD: device gx-ohci, build at  09:41:59 May 27 2015 

--------ohci base= 0xa0a00000
<7>: starting gx OHCI USB Controller no sem_wait.
<7>: Clock to USB host has been enabled 
gx-ohci gx-ohci.0: gx OHCI
gx-ohci gx-ohci.0: new USB bus registered, assigned bus number 2
gx-ohci gx-ohci.0: supports USB remote wakeup
gx-ohci gx-ohci.0: irq 58, io mem 0xa0a00000
usb usb2: default language 0x0409
usb usb2: new device strings: Mfr=3, Product=2, SerialNumber=1
usb usb2: usb_probe_device
usb usb2: configuration #1 chosen from 1 choice
usb usb2: adding 2-:1.0 (config #1, interface 0)
hub 2-:1.0: usb_probe_interface
hub 2-:1.0: usb_probe_interface - got id
hub 2-:1.0: USB hub found
hub 2-:1.0: 1 port detected
hub 2-:1.0: standalone hub
hub 2-:1.0: no power switching (usb 1.0)
hub 2-:1.0: global over-current protection
hub 2-:1.0: power on to power good time: 4ms
hub 2-:1.0: local power source is good
hub 2-:1.0: no over-current condition exists
hub 2-:1.0: trying to enable port power on non-switchable hub
goxceed vserson v1.9.3-4
INFO: mount /dev/flash/0/0x3b0000,0x250000, partition id = 9
usb_hcd_poll_rh_status, 531.
[FB]:start:0x92300000, size:0x1d00000
frontend_mod_init_atbm888x,571


demod svn : 1496 
https://isvn.guoxintech.com/svn/3201_DVBC/demod

fe_profile.demod_type = 7
fe_profile.demod_i2c_id = 0
fe_profile.demod_chip_addr = 0x80
fe_profile.tuner_type = 62
fe_profile.tuner_i2c_id = 0
fe_profile.tuner_chip_addr = 0xc0

---[fun:dvb_ads_mempool_alloc]---[line:44]---[module:2]---[level:5]---Alloc mempool:0x905ed660 ...!
---[fun:dvb_ads_mempool_alloc]---[line:44]---[module:2]---[level:5]---Alloc mempool:0x905ed6c0 ...!
---[fun:dvb_ads_get_logo_config_data]---[line:179]---[module:2]---[level:5]---
	LOGO data Read info 
	x:0
	y:0
	w:720
	,h:576
	pos_type:1
	pic_type:6
	pic_id:28
	data_len = 57163

---[fun:dvb_ads_show_logo]---[line:205]---[module:2]---[level:5]---LOGO config data has been read out to the global var!!!
---[fun:usb_hcd_poll_rh_status, 531.
dvb_ads_show_logo]---[line:211]---[module:2]---[level:5]---Start to show AD LOGO		I_FRAME_PATH=/home/gx/logo.bin
VideoResolution= 1
goxceed version is goxceed-v1.9.3_4
[0;32m[MSG]Build Time:Sep  1 2015 11:13:49
[m[0;32m[MSG]development svn : 1154 
[m[0;32m[MSG]https://isvn.guoxintech.com/svn/3201_DVBC/gongban/development

[m[0;32m[MSG]app_play_register_dolby...
[mAC3 start=0x20000,size = 0x10000
Bin_ReadFromFlashAC3,addr:0x20000,len:0x10000 
check_dataok error
[1;33m[WARN](play/app_common_dolby.c|app_play_register_dolby|15765): Bin_ReadFromFlashAC3 failed.
[m[FB]:start:0x12300000, size:0x1d00000
framebuffer phys = 92300000, mmap = 0x92300000, size = 30408704, mgr = 0x92300000
[GUI]style num: 0
[031m[XML] Parse:[036m 490 [0mms, total[036m 3470 [0mms
hub_events enter...
hub 1-:1.0: state 7 ports 1 chg 0000 evt 0000
hub 1-:1.0: after hub_port_connect_change
hub 2-:1.0: state 7 ports 1 chg 0000 evt 0000
hub 2-:1.0: after hub_port_connect_change
hub_events exit.
hub_events enter...
hub_events exit.
hub_events enter...
hub_events exit.
[cas]	[SC] app_porting_ca_smart_reset handle=0x908d5428 pbyATR=0x90849748,pbyLen=0x90849744
[cas]	[SC] app_porting_ca_smart_reset failed ret=-1 len=0
[cas]	 smart card is not dvb cas smart 
[cas]	app_table_nit_monitor_filter_open
!!!!!!!!!!app_table_nit_monitor_filter_open!!!!!!!!!!!!!!!!!
[cas]	 app_porting_ca_flash_init  size=0x10000
CAUSER start=0x50000,size = 0x10000
app_flash_partion_info_by_name,addr:0x50000,len:0x10000 
[cas]	 app_porting_ca_flash_read_data   Offset=0x0  pdwLen=0x4
[cas]	 app_porting_ca_flash_read_data   Offset=0x4  pdwLen=0xd548
DVBCA_DB_LoadMail:0:0
[cas]	 app_porting_ca_flash_read_data   Offset=0xd54c  pdwLen=0x190
DVBCA_DB_LoadDelMailID:0:0
[cas]	 app_porting_ca_flash_read_data   Offset=0xd6dc  pdwLen=0x1
[cas]	 app_porting_ca_flash_read_data   Offset=0xd8d0  pdwLen=0x1
[cas]	 app_porting_ca_flash_read_data   Offset=0xdac4  pdwLen=0x8
[cas]	 app_porting_ca_flash_read_data   Offset=0xdde4  pdwLen=0x4
[cas]	 app_porting_ca_flash_read_data   Offset=0xe5b4  pdwLen=0x1800
iResult:0
[cas]	DVBSTBCA_RegisterTask szName=CardTask	ucPriority=10
[cas]	DVBSTBCA_RegisterTask szName=MsgTask	ucPriority=10
[cas]	DVBSTBCA_RegisterTask szName=UrgentTask	ucPriority=10
[cas]	app_table_ota_monitor_filter_open
!!!!!!!!!!app_table_ota_monitor_filter_open!!!!!!!!!!!!!!!!!
[app_ota_tuner_mainfreq]lock main freq(770 6875 3).
[cas]	[SC] app_porting_ca_smart_card_status_notify
[cas]	[SC] insert
[cas]	[SC] app_porting_ca_smart_reset handle=0x90e70fa8 pbyATR=0x90e73c48,pbyLen=0x90e73c44




 app_search_lock_tp begin 


DVB: initialising frontend (atbm886x DTMB)...
#mxl608_init,demod_type:0
MXL608_tuner_init_DVBT ok
[mxl608_set_params:49] freq = 770000000.
bandwidth = 6875000.
#MXL608_tuner_DVBT,nRFfreq:770000000,bandwidth:6875000.
Tuner locked
	[SC]atbm886x locked time = 400 ms
 ATR  len=8
	[app_search_lock_tp]:127

 [app_common]app_search_lock_tp lock  

0x3b,0x94,0x11,0x00,0x97,0x04,0x01,0x00,
	
[cas]	[SC] Reset OK
[cas]	app_dvb_cas_api_reset_ecm_filter.
[cas]	app_dvb_cas_api_start_ecm_filter 
[cas]	app_dvb_cas_api_start_ecm_filter old_p_audio_pid=0x0 old_p_ecm_pid =0x0
[cas]	app_dvb_cas_api_start_ecm_filter old_p_video_pid=0x0 old_p_ecm_pid =0x0
[cas]	app_dvb_cas_api_start_ecm_filter old_p_video_pid=0x0 old_p_ecm_pid_video =0x0
[cas]	app_dvb_cas_api_start_ecm_filter old_p_video_pid=0x0 old_p_ecm_pid_video =0x0
[cas]	app_dvb_cas_api_start_ecm_filter End
[cas]	app_dvb_cas_api_reset_emm_filter 
[cas]	ECM ucFilterNum=1 usPid = 0x0
[cas]	ECM ucFilterNum=1 usPid = 0x0
[cas]	ECM ucFilterNum=1 usPid = 0x0
[app_ota_tuner_mainfreq]lock main freq(770) success@@@

---[fun:app_init]---[line:400]---[module:2]---[level:5]---func:app_otoa_tuner_mainfreq() excute successful!!!
---[fun:app_init]---[line:405]---[module:2]---[level:5]---Start to init the DVB ads[AD_INIT] tmp_maintp.nim_modulate= 3 
ADS:ads_module_config.flash_start_adr= 0x30000, flash_size = 0x20000 
[adt] ads_adt_dvbad_attach,196 

---[fun:ads_adt_dvbad_attach]---[line:225]---[module:2]---[level:5]---p_cfg channel_frequency 770, channel_symbolrate 6875, channel_qam3
---[fun:ads_adt_dvbad_open]---[line:90]---[module:2]---[level:5]---DVB AD OPEN!!!


---[fun:dvb_mempool_create]---[line:48]---[module:2]---[level:5]---Info of the mempool alloced:
---[fun:dvb_mempool_create]---[line:49]---[module:2]---[level:5]---	Pool Start Addr:				0x90d2a1a0
---[fun:dvb_mempool_create]---[line:50]---[module:2]---[level:5]---	Pool manage size:				36
---[fun:dvb_mempool_create]---[line:51]---[module:2]---[level:5]---	Block Start Addr:				0x90d11160
---[fun:dvb_mempool_create]---[line:52]---[module:2]---[level:5]---	Block End Addr:				0x90d2a2f0
---[fun:dvb_mempool_create]---[line:53]---[module:2]---[level:5]---	Block size:					1028
---[fun:dvb_mempool_create]---[line:54]---[module:2]---[level:5]---	Block number:				100
---[fun:dvb_mempool_create]---[line:55]---[module:2]---[level:5]---	Block free/used(blocks):			100/0

---[fun:dvbad_ads_client_init]---[line:2288]---[module:2]---[level:5]---Create mempool success!!!
---[fun:dvbad_ads_client_init]---[line:2290]---[module:2]---[level:5]---alloc from mempool sizeof(dvbad_ads_pid_data) = 276
---[fun:dvb_ads_mempool_alloc]---[line:44]---[module:2]---[level:5]---Alloc mempool:0x90d2a200 ...!
---[fun:dvb_ads_mempool_alloc]---[line:44]---[module:2]---[level:5]---Alloc mempool:0x90d2a340 ...!
---[fun:dvbad_ads_client_init]---[line:2315]---[module:2]---[level:5]---Alloc mem for thread addr:0x90d2a340,size:128KB!!!
---[fun:dvbad_ads_client_init]---[line:2321]---[module:2]---[level:5]---Thread create success!!!priority = 10 



 app_search_lock_tp begin 


[app_search_lock_tp]:127

---[fun:ads_dvbad_data_monitor]---[line:1950]---[module:2]---[level:5]---index = 0,ad->filter[index].filter_id = 0
---[fun:ads_dvbad_data_monitor]---[line:1950]---[module:2]---[level:5]---index = 1,ad->filter[index].filter_id = 0
---[fun:ads_dvbad_data_monitor]---[line:1950]---[module:2]---[level:5]---index = 2,ad->filter[index].filter_id = 0
---[fun:ads_dvbad_data_monitor]---[line:1950]---[module:2]---[level:5]---index = 3,ad->filter[index].filter_id = 0
---[fun:ads_dvbad_data_monitor]---[line:1950]---[module:2]---[level:5]---index = 4,ad->filter[index].filter_id = 0
---[fun:ads_dvbad_data_monitor]---[line:1950]---[module:2]---[level:5]---index = 5,ad->filter[index].filter_id = 0
---[fun:ads_dvbad_data_monitor]---[line:1950]---[module:2]---[level:5]---index = 6,ad->filter[index].filter_id = 0
---[fun:ads_dvbad_data_monitor]---[line:1950]---[module:2]---[level:5]---index = 7,ad->filter[index].filter_id = 0
---[fun:ads_dvbad_data_monitor]---[line:1950]---[module:2]---[level:5]---index = 8,ad->filter[index].filter_id = 0
---[fun:ads_dvbad_data_monitor]---[line:1950]---[module:2]---[level:5]---index = 9,ad->filter[index].filter_id = 0
---[fun:ads_dvbad_data_monitor]---[line:1950]---[module:2]---[level:5]---index = 10,ad->filter[index].filter_id = 0
---[fun:ads_dvbad_data_monitor]---[line:1950]---[module:2]---[level:5]---index = 11,ad->filter[index].filter_id = 0
---[fun:ads_dvbad_data_monitor]---[line:1950]---[module:2]---[level:5]---index = 12,ad->filter[index].filter_id = 0
---[fun:ads_dvbad_data_monitor]---[line:1950]---[module:2]---[level:5]---index = 13,ad->filter[index].filter_id = 0
---[fun:ads_dvbad_data_monitor]---[line:1950]---[module:2]---[level:5]---index = 14,ad->filter[index].filter_id = 0
---[fun:ads_dvbad_data_monitor]---[line:1950]---[module:2]---[level:5]---index = 15,ad->filter[index].filter_id = 0[Frontend-0]: TS Locked!...

 [app_common]app_search_lock_tp lock  


---[fun:dvbad_set_filter_bat]---[line:1498]---[module:2]---[level:5]---Alloced BAT filter start!!!

---[fun:dvbad_alloc_filter_bat]---[line:1374]---[module:2]---[level:5]---		Alloced channel_handle = 0x908d54c8
---[fun:dvbad_alloc_filter_bat]---[line:1383]---[module:2]---[level:5]---		Alloced filter_handle = 0x908d59f8
---[fun:dvbad_alloc_filter_bat]---[line:1397]---[module:2]---[level:5]---		Alloced filter_id = 0 for BAT pid = 0x1f41

---[fun:dvbad_set_filter_bat]---[line:1505]---[module:2]---[level:5]---alloc filter success and filterID is 0
---[fun:dvbad_set_filter_bat]---[line:1522]---[module:2]---[level:5]---Start to set filter for BAT...
---[fun:_dvbad_set_filter]---[line:1449]---[module:2]---[level:5]---filterID = 0 start setting...
---[fun:_dvbad_set_filter]---[line:1454]---[module:2]---[level:5]---usChannelPid:0x1f41 

---[fun:_dvbad_set_filter]---[line:1455]---[module:2]---[level:5]---ucFilterLen:11 

---[fun:_dvbad_set_filter]---[line:1462]---[module:2]---[level:5]---The filter handle get by filerID is 0x908d59f8
	mask  len=11
	0xff,0x00,0x00,0xff,0xff,0x00,0xff,0x00,0x00,0x00,0xff,
	
	match  len=11
	0x4a,0x00,0x00,0xff,0x00,0x00,0x00,0x00,0x00,0x00,0xf0,
	

---[fun:_dvbad_set_filter]---[line:1482]---[module:2]---[level:5]---The channel handle get by filterID is 0x908d54c8
---[fun:_dvbad_set_filter]---[line:1486]---[module:2]---[level:5]---The filter handle get by filterID is 0x908d59f8

---[fun:dvbad_set_filter_bat]---[line:1528]---[module:2]---[level:5]---dvbad set filter bat sucess
---[fun:dvbad_set_filter_bat]---[line:1529]---[module:2]---[level:5]---Set filter for BAT end...

---[fun:ads_adt_dvbad_open]---[line:99]---[module:2]---[level:5]---The main thread start to monitor the flag of get_ad_flag!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:1978]---[module:2]---[level:5]---DATA filtered out!!!
---[fun:ads_dvbad_data_monitor]---[line:1979]---[module:2]---[level:5]---Data queryed info : table_id = 0x4a 	 ext_id = 0xff00,pic_id = 65280

---[fun:dvbad_free_filter_bat]---[line:1419]---[module:2]---[level:5]---free BAT filter id = 0

---[fun:dvbad_free_filter_bat]---[line:1424]---[module:2]---[level:5]---free BAT filter handle = 0x908d59f8
---[fun:dvbad_free_filter_bat]---[line:1431]---[module:2]---[level:5]---free BAT filter channel handle = 0x908d54c8
---[fun:ads_dvbad_data_monitor]---[line:1985]---[module:2]---[level:5]---BAT data fitered out!!!
---[fun:minifs_open error.
parser_bat_data]---[line:1854]---[module:2]---[level:5]---Start to parse BAT DATA!!!
---[fun:dvb_ads_get_flash_bat_data]---[line:263]---[module:2]---[level:5]---Read the ad_save_info_t data from flash to global var!!!
---[fun:dvb_ads_check_need_upgrade]---[line:1833]---[module:2]---[level:5]---AD VERSION need upgrade!!!
---[fun:parser_bat_data]---[line:1896]---[module:2]---[level:5]---New version get!!!
---[fun:parser_bat_data]---[line:1901]---[module:2]---[level:5]---Ctrl info filter start!!!

---[fun:dvbad_alloc_filter_ads]---[line:1211]---[module:2]---[level:5]---		Alloced channel_handle = 0x908d54c8
---[fun:dvbad_alloc_filter_ads]---[line:1230]---[module:2]---[level:5]---		Alloced filter_handle = 0x908d59f8
---[fun:dvbad_alloc_filter_ads]---[line:1246]---[module:2]---[level:5]---		Alloced filter_id = 0
---[fun:dvbad_alloc_filter_ads]---[line:1252]---[module:2]---[level:5]---		This filter is for pid = 0x1f40
---[fun:dvbad_alloc_filter_ads]---[line:1264]---[module:2]---[level:5]---		This filter is for HEAD info table_id = 0xfe
---[fun:dvbad_alloc_filter_ads]---[line:1268]---[module:2]---[level:5]---		This filter is for CTRL info ext_id = 0x0
---[fun:_dvbad_set_filter]---[line:1449]---[module:2]---[level:5]---filterID = 0 start setting...
---[fun:_dvbad_set_filter]---[line:1454]---[module:2]---[level:5]---usChannelPid:0x1f40 

---[fun:_dvbad_set_filter]---[line:1455]---[module:2]---[level:5]---ucFilterLen:8 

---[fun:_dvbad_set_filter]---[line:1462]---[module:2]---[level:5]---The filter handle get by filerID is 0x908d59f8
	mask  len=8
	0xff,0x00,0x00,0xff,0xff,0x00,0xff,0xff,
	
	match  len=8
	0xfe,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
	

---[fun:_dvbad_set_filter]---[line:1482]---[module:2]---[level:5]---The channel handle get by filterID is 0x908d54c8
---[fun:_dvbad_set_filter]---[line:1486]---[module:2]---[level:5]---The filter handle get by filterID is 0x908d59f8

---[fun:dvbad_set_filter_ctrl_info]---[line:1818]---[module:2]---[level:5]---dvbad_set_filter_CTRL_INFO return true

---[fun:ads_dvbad_data_monitor]---[line:1993]---[module:2]---[level:5]---The BAT data parsered successful!!!
---[fun:ads_dvbad_data_monitor]---[line:1994]---[module:2]---[level:5]---The Ctrl INFO filter has been set up in the fun parse_bat_data
---[fun:ads_dvbad_data_monitor]---[line:1998]---[module:2]---[level:5]---The BAT info file is not exit!!! Running for the first time!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:1978]---[module:2]---[level:5]---DATA filtered out!!!
---[fun:ads_dvbad_data_monitor]---[line:1979]---[module:2]---[level:5]---Data queryed info : table_id = 0xfe 	 ext_id = 0x0,pic_id = 0

---[fun:ads_dvbad_data_monitor]---[line:2025]---[module:2]---[level:5]---filter id = 0, p_data[0] = 0xfe, table_extension_id = 0x0, section_number = 0, last_section_number 0, data_type 0

---[fun:ads_dvbad_data_monitor]---[line:2030]---[module:2]---[level:5]---CTRL data filtered out!!!
---[fun:ads_dvbad_data_monitor]---[line:2031]---[module:2]---[level:5]---Start to parse the CTRL data!!!
---[fun:dvbad_get_parser_down_ctrl_info]---[line:428]---[module:2]---[level:5]---xml_table_id_start = 1,xml_table_id_end = 1,xml_size = 2018
---[fun:dvbad_get_parser_down_ctrl_info]---[line:429]---[module:2]---[level:5]---pic_info_table_id_start = 2,pic_info_table_id_end = 2,pic_info_size = 6360838

---[fun:dvbad_free_filter_ads]---[line:1320]---[module:2]---[level:5]---filterID = 0, ad->filter[filterID].table_id = 0xfe,ad->filter[filterID].filter_status = 1(0 for free/1 for used)


---[fun:dvbad_free_filter_ads]---[line:1320]---[module:2]---[level:5]---filterID = 1, ad->filter[filterID].table_id = 0xfe,ad->filter[filterID].filter_status = 0(0 for free/1 for used)


---[fun:dvbad_free_filter_ads]---[line:1320]---[module:2]---[level:5]---filterID = 2, ad->filter[filterID].table_id = 0xfe,ad->filter[filterID].filter_status = 0(0 for free/1 for used)


---[fun:dvbad_free_filter_ads]---[line:1320]---[module:2]---[level:5]---filterID = 3, ad->filter[filterID].table_id = 0xfe,ad->filter[filterID].filter_status = 0(0 for free/1 for used)


---[fun:dvbad_free_filter_ads]---[line:1320]---[module:2]---[level:5]---filterID = 4, ad->filter[filterID].table_id = 0xfe,ad->filter[filterID].filter_status = 0(0 for free/1 for used)


---[fun:dvbad_free_filter_ads]---[line:1320]---[module:2]---[level:5]---filterID = 5, ad->filter[filterID].table_id = 0xfe,ad->filter[filterID].filter_status = 0(0 for free/1 for used)


---[fun:dvbad_free_filter_ads]---[line:1320]---[module:2]---[level:5]---filterID = 6, ad->filter[filterID].table_id = 0xfe,ad->filter[filterID].filter_status = 0(0 for free/1 for used)


---[fun:dvbad_free_filter_ads]---[line:1320]---[module:2]---[level:5]---filterID = 7, ad->filter[filterID].table_id = 0xfe,ad->filter[filterID].filter_status = 0(0 for free/1 for used)


---[fun:dvbad_free_filter_ads]---[line:1320]---[module:2]---[level:5]---filterID = 8, ad->filter[filterID].table_id = 0xfe,ad->filter[filterID].filter_status = 0(0 for free/1 for used)


---[fun:dvbad_free_filter_ads]---[line:1320]---[module:2]---[level:5]---filterID = 9, ad->filter[filterID].table_id = 0xfe,ad->filter[filterID].filter_status = 0(0 for free/1 for used)


---[fun:dvbad_free_filter_ads]---[line:1320]---[module:2]---[level:5]---filterID = 10, ad->filter[filterID].table_id = 0xfe,ad->filter[filterID].filter_status = 0(0 for free/1 for used)


---[fun:dvbad_free_filter_ads]---[line:1320]---[module:2]---[level:5]---filterID = 11, ad->filter[filterID].table_id = 0xfe,ad->filter[filterID].filter_status = 0(0 for free/1 for used)


---[fun:dvbad_free_filter_ads]---[line:1320]---[module:2]---[level:5]---filterID = 12, ad->filter[filterID].table_id = 0xfe,ad->filter[filterID].filter_status = 0(0 for free/1 for used)


---[fun:dvbad_free_filter_ads]---[line:1320]---[module:2]---[level:5]---filterID = 13, ad->filter[filterID].table_id = 0xfe,ad->filter[filterID].filter_status = 0(0 for free/1 for used)


---[fun:dvbad_free_filter_ads]---[line:1320]---[module:2]---[level:5]---filterID = 14, ad->filter[filterID].table_id = 0xfe,ad->filter[filterID].filter_status = 0(0 for free/1 for used)


---[fun:dvbad_free_filter_ads]---[line:1320]---[module:2]---[level:5]---filterID = 15, ad->filter[filterID].table_id = 0xfe,ad->filter[filterID].filter_status = 0(0 for free/1 for used)

---[fun:dvbad_free_filter_ads]---[line:1328]---[module:2]---[level:5]---free filterID = 0

---[fun:dvbad_free_filter_ads]---[line:1338]---[module:2]---[level:5]---0 filter have been left for ADS_PID!!!

---[fun:dvbad_free_filter_ads]---[line:1346]---[module:2]---[level:5]---Channel handle freed!!!


---[fun:ads_dvbad_data_monitor]---[line:2035]---[module:2]---[level:5]---Ctrl data parse out successful!!!
---[fun:ads_dvbad_data_monitor]---[line:2039]---[module:2]---[level:5]---Start to filter the XML data!!!
---[fun:ads_dvbad_data_monitor]---[line:2040]---[module:2]---[level:5]---Set filter for XML data!!!
---[fun:dvbad_alloc_filter_ads]---[line:1211]---[module:2]---[level:5]---		Alloced channel_handle = 0x908d54c8
---[fun:dvbad_alloc_filter_ads]---[line:1230]---[module:2]---[level:5]---		Alloced filter_handle = 0x908d59f8
---[fun:dvbad_alloc_filter_ads]---[line:1246]---[module:2]---[level:5]---		Alloced filter_id = 0
---[fun:dvbad_alloc_filter_ads]---[line:1252]---[module:2]---[level:5]---		This filter is for pid = 0x1f40
---[fun:dvbad_alloc_filter_ads]---[line:1264]---[module:2]---[level:5]---		This filter is for HEAD info table_id = 0xfe
---[fun:dvbad_alloc_filter_ads]---[line:1273]---[module:2]---[level:5]---		This ext_id is for AD_HEAD: XML or PIC info !!!
---[fun:dvbad_set_filter_for_adhead]---[line:1737]---[module:2]---[level:5]---	[AD_HEAD]Alloc fitlerID = 0 for extid = 0x1
---[fun:_dvbad_set_filter]---[line:1449]---[module:2]---[level:5]---filterID = 0 start setting...
---[fun:_dvbad_set_filter]---[line:1454]---[module:2]---[level:5]---usChannelPid:0x1f40 

---[fun:_dvbad_set_filter]---[line:1455]---[module:2]---[level:5]---ucFilterLen:9 

---[fun:_dvbad_set_filter]---[line:1462]---[module:2]---[level:5]---The filter handle get by filerID is 0x908d59f8
	mask  len=9
	0xff,0x00,0x00,0xff,0xff,0x00,0x00,0x00,0xff,
	
	match  len=9
	0xfe,0x00,0x00,0x00,0x01,0x00,0x00,0x00,0x01,
	

---[fun:_dvbad_set_filter]---[line:1482]---[module:2]---[level:5]---The channel handle get by filterID is 0x908d54c8
---[fun:_dvbad_set_filter]---[line:1486]---[module:2]---[level:5]---The filter handle get by filterID is 0x908d59f8

---[fun:_set_filter_for_adhead]---[line:1717]---[module:2]---[level:5]---		[AD_HEAD] set filter_id = 0 ext_id:1 end .ret:6
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:1978]---[module:2]---[level:5]---DATA filtered out!!!
---[fun:ads_dvbad_data_monitor]---[line:1979]---[module:2]---[level:5]---Data queryed info : table_id = 0xfe 	 ext_id = 0x1,pic_id = 1

---[fun:ads_dvbad_data_monitor]---[line:2025]---[module:2]---[level:5]---filter id = 0, p_data[0] = 0xfe, table_extension_id = 0x1, section_number = 0, last_section_number 0, data_type 1

---[fun:add_data_to_filter_list]---[line:558]---[module:2]---[level:5]---add new p_data

---[fun:create_filter_buf_list]---[line:488]---[module:2]---[level:5]---Alloc mem for filter_buf_node ,size : 12
---[fun:dvb_ads_mempool_alloc]---[line:44]---[module:2]---[level:5]---Alloc mempool:0x90d6b400 ...!
---[fun:create_filter_buf_list]---[line:492]---[module:2]---[level:5]-------Alloc mem for filter_buf_node success,point to: 0x90d6b400!!!
---[fun:create_filter_buf_list]---[line:493]---[module:2]---[level:5]---Alloc mem for filter_buf_node.p_data,size = 2032
---[fun:dvb_ads_mempool_alloc]---[line:44]---[module:2]---[level:5]---Alloc mempool:0x90edc8a0 ...!
---[fun:create_filter_buf_list]---[line:502]---[module:2]---[level:5]-------filter_buf_node.p_data point to :0x90edc8a0
---[fun:create_filter_buf_list]---[line:503]---[module:2]---[level:5]---Data saved to the filter_buf_node.p_data mem
---[fun:create_filter_buf_list]---[line:508]---[module:2]---[level:5]---filter buffer list created!!!
---[fun:add_node_to_fl]---[line:827]---[module:2]---[level:5]---add data to filter list success
---[fun:check_fl_complete]---[line:698]---[module:2]---[level:5]---Start to check ext_id = 1 filter completed or not!!!
*******************************************************************************************

---[fun:check_fl_complete]---[line:718]---[module:2]---[level:5]---For pic_id = 1,last_sec = 0,sec = 0 has been saved
---[fun:check_fl_complete]---[line:719]---[module:2]---[level:5]---Alloc mem As FLAG for pic_id = 1 to record the sec has been saved
---[fun:check_fl_complete]---[line:738]---[module:2]---[level:5]---ext_id = 1,sec = 0 has been save to filter list!!!
---[fun:check_fl_complete]---[line:752]---[module:2]---[level:5]---Pic_id = 1 is filtered completed and free the temp flag!!!
---[fun:check_fl_complete]---[line:754]---[module:2]---[level:5]---free the temp flag end!!!
---[fun:check_fl_complete]---[line:758]---[module:2]---[level:5]---Picture of the pic_id = 1 fitlered out completly!!!
*******************************************************************************************

---[fun:add_node_to_fl]---[line:830]---[module:2]---[level:5]---One ext_id data filtered out completely
---[fun:ads_dvbad_data_monitor]---[line:2049]---[module:2]---[level:5]---Free XML or PIC_INFO filter!!!

---[fun:dvbad_free_filter_ads]---[line:1320]---[module:2]---[level:5]---filterID = 0, ad->filter[filterID].table_id = 0xfe,ad->filter[filterID].filter_status = 1(0 for free/1 for used)


---[fun:dvbad_free_filter_ads]---[line:1320]---[module:2]---[level:5]---filterID = 1, ad->filter[filterID].table_id = 0xfe,ad->filter[filterID].filter_status = 0(0 for free/1 for used)


---[fun:dvbad_free_filter_ads]---[line:1320]---[module:2]---[level:5]---filterID = 2, ad->filter[filterID].table_id = 0xfe,ad->filter[filterID].filter_status = 0(0 for free/1 for used)


---[fun:dvbad_free_filter_ads]---[line:1320]---[module:2]---[level:5]---filterID = 3, ad->filter[filterID].table_id = 0xfe,ad->filter[filterID].filter_status = 0(0 for free/1 for used)


---[fun:dvbad_free_filter_ads]---[line:1320]---[module:2]---[level:5]---filterID = 4, ad->filter[filterID].table_id = 0xfe,ad->filter[filterID].filter_status = 0(0 for free/1 for used)


---[fun:dvbad_free_filter_ads]---[line:1320]---[module:2]---[level:5]---filterID = 5, ad->filter[filterID].table_id = 0xfe,ad->filter[filterID].filter_status = 0(0 for free/1 for used)


---[fun:dvbad_free_filter_ads]---[line:1320]---[module:2]---[level:5]---filterID = 6, ad->filter[filterID].table_id = 0xfe,ad->filter[filterID].filter_status = 0(0 for free/1 for used)


---[fun:dvbad_free_filter_ads]---[line:1320]---[module:2]---[level:5]---filterID = 7, ad->filter[filterID].table_id = 0xfe,ad->filter[filterID].filter_status = 0(0 for free/1 for used)


---[fun:dvbad_free_filter_ads]---[line:1320]---[module:2]---[level:5]---filterID = 8, ad->filter[filterID].table_id = 0xfe,ad->filter[filterID].filter_status = 0(0 for free/1 for used)


---[fun:dvbad_free_filter_ads]---[line:1320]---[module:2]---[level:5]---filterID = 9, ad->filter[filterID].table_id = 0xfe,ad->filter[filterID].filter_status = 0(0 for free/1 for used)


---[fun:dvbad_free_filter_ads]---[line:1320]---[module:2]---[level:5]---filterID = 10, ad->filter[filterID].table_id = 0xfe,ad->filter[filterID].filter_status = 0(0 for free/1 for used)


---[fun:dvbad_free_filter_ads]---[line:1320]---[module:2]---[level:5]---filterID = 11, ad->filter[filterID].table_id = 0xfe,ad->filter[filterID].filter_status = 0(0 for free/1 for used)


---[fun:dvbad_free_filter_ads]---[line:1320]---[module:2]---[level:5]---filterID = 12, ad->filter[filterID].table_id = 0xfe,ad->filter[filterID].filter_status = 0(0 for free/1 for used)


---[fun:dvbad_free_filter_ads]---[line:1320]---[module:2]---[level:5]---filterID = 13, ad->filter[filterID].table_id = 0xfe,ad->filter[filterID].filter_status = 0(0 for free/1 for used)


---[fun:dvbad_free_filter_ads]---[line:1320]---[module:2]---[level:5]---filterID = 14, ad->filter[filterID].table_id = 0xfe,ad->filter[filterID].filter_status = 0(0 for free/1 for used)


---[fun:dvbad_free_filter_ads]---[line:1320]---[module:2]---[level:5]---filterID = 15, ad->filter[filterID].table_id = 0xfe,ad->filter[filterID].filter_status = 0(0 for free/1 for used)

---[fun:dvbad_free_filter_ads]---[line:1328]---[module:2]---[level:5]---free filterID = 0

---[fun:dvbad_free_filter_ads]---[line:1338]---[module:2]---[level:5]---0 filter have been left for ADS_PID!!!

---[fun:dvbad_free_filter_ads]---[line:1346]---[module:2]---[level:5]---Channel handle freed!!!


---[fun:check_fl_complete]---[line:698]---[module:2]---[level:5]---Start to check ext_id = 1 filter completed or not!!!
*******************************************************************************************

---[fun:check_fl_complete]---[line:718]---[module:2]---[level:5]---For pic_id = 1,last_sec = 0,sec = 0 has been saved
---[fun:check_fl_complete]---[line:719]---[module:2]---[level:5]---Alloc mem As FLAG for pic_id = 1 to record the sec has been saved
---[fun:check_fl_complete]---[line:738]---[module:2]---[level:5]---ext_id = 1,sec = 0 has been save to filter list!!!
---[fun:check_fl_complete]---[line:752]---[module:2]---[level:5]---Pic_id = 1 is filtered completed and free the temp flag!!!
---[fun:check_fl_complete]---[line:754]---[module:2]---[level:5]---free the temp flag end!!!
---[fun:check_fl_complete]---[line:758]---[module:2]---[level:5]---Picture of the pic_id = 1 fitlered out completly!!!
*******************************************************************************************

---[fun:dvbad_check_adhead_complete]---[line:1766]---[module:2]---[level:5]---XML info has been filtered out completly!!!
---[fun:ads_dvbad_data_monitor]---[line:2056]---[module:2]---[level:5]---Start to parse the XML data!!!
---[fun:dvb_ads_mempool_alloc]---[line:44]---[module:2]---[level:5]---Alloc mempool:0x90d6a3c0 ...!
---[fun:parser_head_xml_data]---[line:907]---[module:2]---[level:5]---ad->xml is NULL ,Remalloc,size:ad->down_ctl.ads_xml_info.index_xml_size:2018
---[fun:parser_head_xml_data]---[line:914]---[module:2]---[level:5]---Init ad->xml space all 0
---[fun:parser_head_xml_data]---[line:923]---[module:2]---[level:5]---table_extension_id: 1!



---[fun:parser_head_xml_data]---[line:928]---[module:2]---[level:5]---sec = 0 ,last_sec = 0!

---[fun:get_next_head_node]---[line:583]---[module:2]---[level:5]---data_type:1,table_extension_id:1,section_number:0
---[fun:parser_head_xml_data]---[line:957]---[module:2]---[level:5]---sizeof(dvbad_ads_pic_data) 276

---[fun:ads_xml_parse]---[line:422]---[module:2]---[level:5]---xml parse start

---[fun:ads_xml_parse]---[line:428]---[module:2]---[level:5]---start to get doc

---[fun:ads_xml_parse]---[line:430]---[module:2]---[level:5]---get doc end

---[fun:ads_xml_parse]---[line:436]---[module:2]---[level:5]---Start to get root

---[fun:ads_xml_parse]---[line:438]---[module:2]---[level:5]---Get root end

---[fun:ads_xml_parse]---[line:452]---[module:2]---[level:5]---Start to get child type

---[fun:ads_xml_parse]---[line:454]---[module:2]---[level:5]---Get child type end

---[fun:ads_xml_parse]---[line:456]---[module:2]---[level:5]---Start to parse type

---[fun:ads_xml_pic_attribute_parse]---[line:204]---[module:2]---[level:5]---XML receive file_number = 1 name:Logo1

---[fun:ads_xml_pic_attribute_parse]---[line:205]---[module:2]---[level:5]---XML parse:
		file_number:	1
		version:		1
		duration:		0
		x:			0
		y:			0
		w:			720
		h:			576
		p_format:		6
		type:			1

---[fun:ads_xml_pic_attribute_parse]---[line:204]---[module:2]---[level:5]---XML receive file_number = 3 name:ad4

---[fun:ads_xml_pic_attribute_parse]---[line:205]---[module:2]---[level:5]---XML parse:
		file_number:	3
		version:		4
		duration:		0
		x:			0
		y:			0
		w:			302
		h:			92
		p_format:		1
		type:			6

---[fun:dvb_ads_mempool_alloc]---[line:44]---[module:2]---[level:5]---Alloc mempool:0x90ed7a20 ...!
---[fun:ads_xml_pic_attribute_parse]---[line:204]---[module:2]---[level:5]---XML receive file_number = 4 name:ad5

---[fun:ads_xml_pic_attribute_parse]---[line:205]---[module:2]---[level:5]---XML parse:
		file_number:	4
		version:		2
		duration:		0
		x:			0
		y:			0
		w:			244
		h:			108
		p_format:		1
		type:			6

---[fun:dvb_ads_mempool_alloc]---[line:44]---[module:2]---[level:5]---Alloc mempool:0x90ed7ca0 ...!
---[fun:ads_xml_pic_attribute_parse]---[line:204]---[module:2]---[level:5]---XML receive file_number = 5 name:ad6

---[fun:ads_xml_pic_attribute_parse]---[line:205]---[module:2]---[level:5]---XML parse:
		file_number:	5
		version:		4
		duration:		0
		x:			0
		y:			0
		w:			244
		h:			108
		p_format:		1
		type:			6

---[fun:dvb_ads_mempool_alloc]---[line:44]---[module:2]---[level:5]---Alloc mempool:0x90ed8b20 ...!
---[fun:ads_xml_pic_attribute_parse]---[line:204]---[module:2]---[level:5]---XML receive file_number = 6 name:ad7

---[fun:ads_xml_pic_attribute_parse]---[line:205]---[module:2]---[level:5]---XML parse:
		file_number:	6
		version:		2
		duration:		0
		x:			0
		y:			0
		w:			244
		h:			108
		p_format:		1
		type:			6

---[fun:dvb_ads_mempool_alloc]---[line:44]---[module:2]---[level:5]---Alloc mempool:0x90d6abe0 ...!
---[fun:ads_xml_parse]---[line:458]---[module:2]---[level:5]---End parse type

---[fun:ads_xml_parse]---[line:461]---[module:2]---[level:5]---xml parse end.ret:0

---[fun:parser_head_xml_data]---[line:975]---[module:2]---[level:5]---ext_id:1,type:1,x:0,y:0,w:720,h:576

---[fun:ads_dvbad_data_monitor]---[line:2058]---[module:2]---[level:5]---Free the xml save list!!!
---[fun:free_fl_all]---[line:790]---[module:2]---[level:5]---The data list is not freed outside,free now
---[fun:delete_head_node]---[line:516]---[module:2]---[level:5]---Start to free the filter buf node
---[fun:dvb_ads_mempool_free]---[line:54]---[module:2]---[level:5]---The address is going to be free is 0x90edc8a0
---[fun:dvb_ads_mempool_free]---[line:58]---[module:2]---[level:5]---The address after being freed is 0x0
---[fun:dvb_ads_mempool_free]---[line:64]---[module:2]---[level:5]---free mem success!!!
---[fun:dvb_ads_mempool_free]---[line:54]---[module:2]---[level:5]---The address is going to be free is 0x90d6b400
---[fun:dvb_ads_mempool_free]---[line:58]---[module:2]---[level:5]---The address after being freed is 0x0
---[fun:dvb_ads_mempool_free]---[line:64]---[module:2]---[level:5]---free mem success!!!
---[fun:delete_head_node]---[line:524]---[module:2]---[level:5]---Free one filter_buf_node list
---[fun:free_fl_all]---[line:792]---[module:2]---[level:5]---temp  xml or pic info data filter_rec[0] list has been freed
---[fun:ads_dvbad_data_monitor]---[line:2065]---[module:2]---[level:5]---Xml data has been parsed out successful!!!

---[fun:ads_dvbad_data_monitor]---[line:2068]---[module:2]---[level:5]---pic_infomation_table_id_start = 2,pic_infomation_table_id_end = 2
---[fun:ads_dvbad_data_monitor]---[line:2069]---[module:2]---[level:5]---Start to filter the pic info data!!!
---[fun:dvbad_alloc_filter_ads]---[line:1211]---[module:2]---[level:5]---		Alloced channel_handle = 0x908d54c8
---[fun:dvbad_alloc_filter_ads]---[line:1230]---[module:2]---[level:5]---		Alloced filter_handle = 0x908d59f8
---[fun:dvbad_alloc_filter_ads]---[line:1246]---[module:2]---[level:5]---		Alloced filter_id = 0
---[fun:dvbad_alloc_filter_ads]---[line:1252]---[module:2]---[level:5]---		This filter is for pid = 0x1f40
---[fun:dvbad_alloc_filter_ads]---[line:1264]---[module:2]---[level:5]---		This filter is for HEAD info table_id = 0xfe
---[fun:dvbad_alloc_filter_ads]---[line:1273]---[module:2]---[level:5]---		This ext_id is for AD_HEAD: XML or PIC info !!!
---[fun:dvbad_set_filter_for_adhead]---[line:1737]---[module:2]---[level:5]---	[AD_HEAD]Alloc fitlerID = 0 for extid = 0x2
---[fun:_dvbad_set_filter]---[line:1449]---[module:2]---[level:5]---filterID = 0 start setting...
---[fun:_dvbad_set_filter]---[line:1454]---[module:2]---[level:5]---usChannelPid:0x1f40 

---[fun:_dvbad_set_filter]---[line:1455]---[module:2]---[level:5]---ucFilterLen:9 

---[fun:_dvbad_set_filter]---[line:1462]---[module:2]---[level:5]---The filter handle get by filerID is 0x908d59f8
	mask  len=9
	0xff,0x00,0x00,0xff,0xff,0x00,0x00,0x00,0xff,
	
	match  len=9
	0xfe,0x00,0x00,0x00,0x02,0x00,0x00,0x00,0x02,
	

---[fun:_dvbad_set_filter]---[line:1482]---[module:2]---[level:5]---The channel handle get by filterID is 0x908d54c8
---[fun:_dvbad_set_filter]---[line:1486]---[module:2]---[level:5]---The filter handle get by filterID is 0x908d59f8

---[fun:_set_filter_for_adhead]---[line:1717]---[module:2]---[level:5]---		[AD_HEAD] set filter_id = 0 ext_id:2 end .ret:6
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_adt_dvbad_open]---[line:110]---[module:2]---[level:2]---ad monitor time out

---[fun:ads_adt_dvbad_io_ctrl]---[line:166]---[module:2]---[level:5]---cmd:7,ad_type:0,network_id:0,ts_id:0,service_id:0

---[fun:dvbad_type_get]---[line:149]---[module:2]---[level:5]---get ad_type end.ad_type:1
ad Version:

---[fun:ads_ap_init]---[line:64]---[module:2]---[level:5]---Logo data is ready!!!close the startlog.

[app_win_set_focus_video_window] set the msp index as MESSAGE_MAX_COUNT.
[031m[APP INIT]:[036m 62510 [0mms, total[036m 65320 [0mms
[WARING]: Image NULL No Found NULL

---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!![cas]	[app_dvb_cas_rolling_message_hide]----------
[app_win_set_focus_video_window] set the msp index as MESSAGE_MAX_COUNT.




 app_search_lock_tp begin 


[app_search_lock_tp]:127

 [app_common]app_search_lock_tp lock  

!!!!!!!!!!app_table_nit_monitor_filter_close!!!!!!!!!!!!!!!!!
GXMSG_SI_SUBTABLE_CREATE subtable_id:3
GXMSG_SI_SUBTABLE_START :3

---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!filter nit table timeout  fre = 770!!
!!!!!!!!!!app_table_nit_monitor_filter_close!!!!!!!!!!!!!!!!!
!!!!!!!!!!app_table_ota_monitor_filter_close!!!!!!!!!!!!!!!!!

app_porting_disable_query_demux
cafilter[0].pid = 0x0 
cafilter[0].usedStatus = 0x0 
cafilter[0].Callback = 0x0 
cafilter[0].timeOutCallback = 0x0 
cafilter[0].byReqID = 0x0 
cafilter[0].channelhandle = 0x0 
cafilter[0].handle = 0x0 
cafilter[0].filterLen = 0x0 
cafilter[0].match =
cafilter[0].mask =

cafilter[1].pid = 0x0 
cafilter[1].usedStatus = 0x0 
cafilter[1].Callback = 0x0 
cafilter[1].timeOutCallback = 0x0 
cafilter[1].byReqID = 0x0 
cafilter[1].channelhandle = 0x0 
cafilter[1].handle = 0x0 
cafilter[1].filterLen = 0x0 
cafilter[1].match =
cafilter[1].mask =

cafilter[2].pid = 0x0 
cafilter[2].usedStatus = 0x0 
cafilter[2].Callback = 0x0 
cafilter[2].timeOutCallback = 0x0 
cafilter[2].byReqID = 0x0 
cafilter[2].channelhandle = 0x0 
cafilter[2].handle = 0x0 
cafilter[2].filterLen = 0x0 
cafilter[2].match =
cafilter[2].mask =

cafilter[3].pid = 0x0 
cafilter[3].usedStatus = 0x0 
cafilter[3].Callback = 0x0 
cafilter[3].timeOutCallback = 0x0 
cafilter[3].byReqID = 0x0 
cafilter[3].channelhandle = 0x0 
cafilter[3].handle = 0x0 
cafilter[3].filterLen = 0x0 
cafilter[3].match =
cafilter[3].mask =

cafilter[4].pid = 0x0 
cafilter[4].usedStatus = 0x0 
cafilter[4].Callback = 0x0 
cafilter[4].timeOutCallback = 0x0 
cafilter[4].byReqID = 0x0 
cafilter[4].channelhandle = 0x0 
cafilter[4].handle = 0x0 
cafilter[4].filterLen = 0x0 
cafilter[4].match =
cafilter[4].mask =

cafilter[5].pid = 0x0 
cafilter[5].usedStatus = 0x0 
cafilter[5].Callback = 0x0 
cafilter[5].timeOutCallback = 0x0 
cafilter[5].byReqID = 0x0 
cafilter[5].channelhandle = 0x0 
cafilter[5].handle = 0x0 
cafilter[5].filterLen = 0x0 
cafilter[5].match =
cafilter[5].mask =

cafilter[6].pid = 0x0 
cafilter[6].usedStatus = 0x0 
cafilter[6].Callback = 0x0 
cafilter[6].timeOutCallback = 0x0 
cafilter[6].byReqID = 0x0 
cafilter[6].channelhandle = 0x0 
cafilter[6].handle = 0x0 
cafilter[6].filterLen = 0x0 
cafilter[6].match =
cafilter[6].mask =

cafilter[7].pid = 0x0 
cafilter[7].usedStatus = 0x0 
cafilter[7].Callback = 0x0 
cafilter[7].timeOutCallback = 0x0 
cafilter[7].byReqID = 0x0 
cafilter[7].channelhandle = 0x0 
cafilter[7].handle = 0x0 
cafilter[7].filterLen = 0x0 
cafilter[7].match =
cafilter[7].mask =

cafilter[8].pid = 0x0 
cafilter[8].usedStatus = 0x0 
cafilter[8].Callback = 0x0 
cafilter[8].timeOutCallback = 0x0 
cafilter[8].byReqID = 0x0 
cafilter[8].channelhandle = 0x0 
cafilter[8].handle = 0x0 
cafilter[8].filterLen = 0x0 
cafilter[8].match =
cafilter[8].mask =

cafilter[9].pid = 0x0 
cafilter[9].usedStatus = 0x0 
cafilter[9].Callback = 0x0 
cafilter[9].timeOutCallback = 0x0 
cafilter[9].byReqID = 0x0 
cafilter[9].channelhandle = 0x0 
cafilter[9].handle = 0x0 
cafilter[9].filterLen = 0x0 
cafilter[9].match =
cafilter[9].mask =

cafilter[10].pid = 0x0 
cafilter[10].usedStatus = 0x0 
cafilter[10].Callback = 0x0 
cafilter[10].timeOutCallback = 0x0 
cafilter[10].byReqID = 0x0 
cafilter[10].channelhandle = 0x0 
cafilter[10].handle = 0x0 
cafilter[10].filterLen = 0x0 
cafilter[10].match =
cafilter[10].mask =

cafilter[11].pid = 0x0 
cafilter[11].usedStatus = 0x0 
cafilter[11].Callback = 0x0 
cafilter[11].timeOutCallback = 0x0 
cafilter[11].byReqID = 0x0 
cafilter[11].channelhandle = 0x0 
cafilter[11].handle = 0x0 
cafilter[11].filterLen = 0x0 
cafilter[11].match =
cafilter[11].mask =

cafilter[12].pid = 0x0 
cafilter[12].usedStatus = 0x0 
cafilter[12].Callback = 0x0 
cafilter[12].timeOutCallback = 0x0 
cafilter[12].byReqID = 0x0 
cafilter[12].channelhandle = 0x0 
cafilter[12].handle = 0x0 
cafilter[12].filterLen = 0x0 
cafilter[12].match =
cafilter[12].mask =

cafilter[13].pid = 0x0 
cafilter[13].usedStatus = 0x0 
cafilter[13].Callback = 0x0 
cafilter[13].timeOutCallback = 0x0 
cafilter[13].byReqID = 0x0 
cafilter[13].channelhandle = 0x0 
cafilter[13].handle = 0x0 
cafilter[13].filterLen = 0x0 
cafilter[13].match =
cafilter[13].mask =

cafilter[14].pid = 0x0 
cafilter[14].usedStatus = 0x0 
cafilter[14].Callback = 0x0 
cafilter[14].timeOutCallback = 0x0 
cafilter[14].byReqID = 0x0 
cafilter[14].channelhandle = 0x0 
cafilter[14].handle = 0x0 
cafilter[14].filterLen = 0x0 
cafilter[14].match =
cafilter[14].mask =

cafilter[15].pid = 0x0 
cafilter[15].usedStatus = 0x0 
cafilter[15].Callback = 0x0 
cafilter[15].timeOutCallback = 0x0 
cafilter[15].byReqID = 0x0 
cafilter[15].channelhandle = 0x0 
cafilter[15].handle = 0x0 
cafilter[15].filterLen = 0x0 
cafilter[15].match =
cafilter[15].mask =

cafilter[16].pid = 0x0 
cafilter[16].usedStatus = 0x0 
cafilter[16].Callback = 0x0 
cafilter[16].timeOutCallback = 0x0 
cafilter[16].byReqID = 0x0 
cafilter[16].channelhandle = 0x0 
cafilter[16].handle = 0x0 
cafilter[16].filterLen = 0x0 
cafilter[16].match =
cafilter[16].mask =

cafilter[17].pid = 0x0 
cafilter[17].usedStatus = 0x0 
cafilter[17].Callback = 0x0 
cafilter[17].timeOutCallback = 0x0 
cafilter[17].byReqID = 0x0 
cafilter[17].channelhandle = 0x0 
cafilter[17].handle = 0x0 
cafilter[17].filterLen = 0x0 
cafilter[17].match =
cafilter[17].mask =
[cas]	EMM ucFilterNum=5 usPid = 0x0

---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!FRE: == 770000, 770 MHz 

---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:[mxl608_set_params:49] freq = 706000000.
bandwidth = 6875000.
#MXL608_tuner_DVBT,nRFfreq:706000000,bandwidth:6875000.
Tuner locked
ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!FRE: == 706000, 706 MHz 
[GUI]Filled Rectangle failed!
[GUI]Filled Rectangle failed!

---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!![cas]	app_table_nit_monitor_filter_open
!!!!!!!!!!app_table_nit_monitor_filter_open!!!!!!!!!!!!!!!!!
[cas]	app_table_ota_monitor_filter_restart
[app_win_set_focus_video_window] set the msp index as MESSAGE_MAX_COUNT.
[WARING]: Image NULL No Found NULL

---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!![Frontend-0]: TS Unlock!...

---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!![Frontend-0]: TS Unlock!...

---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!![Frontend-0]: TS Unlock!...

---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!![Frontend-0]: TS Unlock!...

---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!![Frontend-0]: TS Unlock!...

---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!![Frontend-0]: TS Unlock!...

---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!![Frontend-0]: TS Unlock!...

---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!![Frontend-0]: TS Unlock!...

---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
---[fun:ads_dvbad_data_monitor]---[line:2203]---[module:2]---[level:2]---No data queryed!!!
---[fun:ads_dvbad_data_monitor]---[line:1972]---[module:2]---[level:5]---filter_id = 0  filter_handle = 0x908d59f8 is being used!!!
