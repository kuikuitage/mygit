﻿#ifndef FRAME_PRODUCER_H
#define FRAME_PRODUCER_H

#include <mutex>
#include "GpuFrameMock/FrameCommon.h"

class FrameProducer
{
    virtua ~FrameProducer(){}；
    int GetFrameGpuData(uint8_t*&pFrameData, size_t& len){}
    int GetDeviceFrameInfo(CaptureInfo& frameInfo){}
    void DestroyDevice(){}
    void InitDevice(){}
private:
    uint32_t m_width = 720;
    uint32_t m_height = 1280;
    void* pdata = nullptr;
    FILE* fin = nullptr;
    FILE* fout = nullptr;
};

#endif // FRAME_PRODUCER_H