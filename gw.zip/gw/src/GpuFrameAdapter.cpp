#include "GpuFrame.h"
#include "FrameProducer.h"


GpuFrameAdapter::GpuFrameAdapter(FrameProducer* pProducer)
{
    std::lock_guard guard(m_mtx);
    m_producer = pProducer;
}

GpuFrameAdapter::~GpuFrameAdapter()
{
    std::lock_guard guard(m_mtx);
    if(m_producer == nullptr)
    {
        delete m_producer;
    }
}

int GpuFrameAdapter::GetFrameInfo(void* pHandler, CaptureInfo& FrameInfo)
{
    std::lock_guard guard(m_mtx);
    m_producer->GetDeviceFrameInfo();
}

int GpuFrameAdapter::GetYUVFrame(void* pHandler, CaptureInfo& FrameInfo, vector<uint8_t*>& pFrame, size_t& len)
{
    std::lock_guard guard(m_mtx);
    m_producer->GetFrameGpuData();
}

int GpuFrameAdapter::InitFrameChan(void* pHandler)
{
    std::lock_guard guard(m_mtx);
    m_producer->InitDevice();
}

void GpuFrameAdapter::DestroyFrameChan(void* pHandler)
{
    std::lock_guard guard(m_mtx);
    m_producer->DestroyDevice();
}