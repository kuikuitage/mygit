﻿#ifndef FRAME_COMMON_H
#define FRAME_COMMON_H

#ifndef uin8_t
typedef unsigned char uint8_t;
#endif

#ifndef int8_t
typedef signed char int8_t;
#endif

#ifndef uin16_t
typedef unsigned short uint16_t;
#endif

#ifndef int16_t
typedef signed short int16_t;
#endif

#ifndef uin32_t
typedef unsigned int uint32_t;
#endif

#ifndef int32_t
typedef signed int int32_t;
#endif

#ifndef uint64_t
typedef unsigned long long uint64_t;
#endif

#ifndef int64_t
typedef signed long long int64_t;
#endif


// 图像格式
enum GpuFrameFormat:uint8_t
{
	FORMAT_RAW = 0x01,
	FORMAT_YUV = 0x02,
	FORMAT_INVALID = 0x00
};


struct GpuFrameInfo
{
	GpuFrameFormat format;
    uint32_t width; // 图像宽
    uint32_t height; // 图像高
    uint32_t stride; // 图像步长
    uint64_t timestamp; //时间戳
};

struct CaptureInfo
{
    uint8_t orientation; // 旋转角度：0不旋转，1旋转90°，2旋转180°，3旋转270°
    GpuFrameInfo info;
};

#endif // FRAME_COMMON_H