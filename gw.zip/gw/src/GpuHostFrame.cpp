#include "GpuHostFrame.h"

GpuHostFrame::~GpuHostFrame()
{

}

int GpuHostFrame::GetFrameInfo(void* pHandler, CaptureInfo& FrameInof, vector<uint8_t*>& pFrame, size_t& len)
{

}

int GpuHostFrame::GetYUVFrame(void* pHandler, CaptureInfo& FrameInfo, vector<uint8_t*>& pFrame, size_t& len
{

}
int GpuHostFrame::InitFrameChan(void* pHandler)
{

}

void* GpuHostFrame::DestroyFrameChn(void* pHandler)
{

}