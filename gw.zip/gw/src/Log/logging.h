#ifndef LOGGING_H
#define LOGGING_H

#define LOG_FILE    ("/var/tmp/log")

#define INFO(FORMAT, args...)\
    do{\

        FILE* gw_log = fopen(LOG_FILE, "a+");\
        if(NULL != gw_log)\
        {\
            fprintf(gw_log, FORMAT, ##args);\
            fclose(gw_log);\
        }\
    }while(0);

#endif // LOGGING_H