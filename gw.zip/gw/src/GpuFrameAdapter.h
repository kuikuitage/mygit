#include "GpuFrame.h"
#include "FrameProducer.h"

Class GpuFrameAdapter:public GpuFrame
{
public:
    GpuFrameAdapter(FrameProducer* pProducer);
    virtual ~GpuFrameAdapter();
    virtual int GetFrameInfo(void* pHandler, CaptureInfo& FrameInfo);
    virtual int GetYUVFrame(void* pHandler, CaptureInfo& FrameInfo, vector<uint8_t*>& pFrame, size_t& len);
    virtual int InitFrameChan(void* pHandler);
    virtual void DestroyFrameChan(void* pHandler);
private:
    FrameProducer* m_producer = nullptr;
    std::mutex m_mtx;
};