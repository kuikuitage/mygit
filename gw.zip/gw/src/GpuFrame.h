﻿#ifndef GPU_FRAME_H
#define GPU_FRAME_H

#include <mutex>
#include <vector>
#include "GpuFrameMock/FrameCommon.h"
#include "Log/logging.h"

using namespace std;

class GpuFrame
{
public:
    virtual ~GpuFrame(){};
    virtual int GetFrameInfo(void* pHandler, CaptureInfo& FrameInfo){}
    virtual int GetYUVFrame(void* pHandler, CaptureInfo& FrameInfo, vector<uint8_t*>& pFrame, size_t& len){}
    virtual int InitFrameChan(void* pHandler){}
    virtual void DestroyFrameChan(void* pHandler){}
private:
    
};

#endif //GPU_FRAME_H