﻿#ifndef GPU_HOST_FRAME_H
#define GPU_HOST_FRAME_H

#include <mutex>
#include <vector>
#include "GpuFrame.h"
#include "GpuFrameAdapter.h"

class GpuHostFrame : public GpuFrame
{
public:
	GpuHostFrame();
	virtual ~GpuHostFrame();
	int GetFrameInfo(void* pHandler, CaptureInfo& FrameInof, vector<uint8_t*>& pFrame, size_t& len);
	int GetYUVFrame(void* pHandler, CaptureInfo& FrameInfo, vector<uint8_t*>& pFrame, size_t& len)
	int InitFrameChan(void* pHandler);
	void* DestroyFrameChn(void* pHandler);
};

#endif //GPU_HOST_FRAME_H