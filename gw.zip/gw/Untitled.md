```shell
sudo update-alternatives --install /usr/bin/gcc gcc /home/gw/gcc-aarch64/bin/aarch64-linux-gnu-gcc 40
sudo update-alternatives --install /usr/bin/gcc gcc /usr/bin/gcc-4.8.5 20

sudo update-alternatives --install /usr/bin/g++ g++ /home/gw/gcc-aarch64/bin/aarch64-linux-gnu-g++ 40
sudo update-alternatives --install /usr/bin/g++ g++ /usr/bin/g++-4.8.5 20
```



- sudo update-alternatives --install /usr/bin/gcc gcc /usr/bin/gcc-5 40
- `sudo update-alternatives --install /usr/bin/g++ g++ /usr/bin/g++-5 40`





sudo update-alternatives --config gcc

sudo update-alternatives --config g++