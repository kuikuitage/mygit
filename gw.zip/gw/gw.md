gpuFrame.h

```c++
#ifndef GPU_FRAME_H
#define GPU_FRAME_H

#include <mutex>
#include <vector>
#include "GpuFrameMock/FrameCommon.h"
#include "Log/logging.h"

using namespace std;


class GpuFrame
{
public:
    virtual ~GpuFrame();
    virtual int GetFrameInfo(void* pHandler, CaptureInfo& FrameInfo){}
    virtual int GetYUVFrame(void* pHandler, CaptureInfo& FrameInfo, vector<uint8_t*>& pFrame, size_t& len){}
    virtual int InitFrameChan(void* pHandler){}
    virtual void DestroyFrameChan(void* pHandler){}

private:
    
};

#endif //GPU_FRAME_H
```



frameCommon.h

```c++
#ifndef FRAME_COMMON_H
#define FRAME_COMMON_H

// 图像格式
enum GpuFrameFormat:uint8_t
{
	FORMAT_RAW = 0x01,
	FORMAT_YUV = 0x02,
	FORMAT_INVALID = 0x00
};


struct GpuFrameInfo
{
	GpuFrameFormat format;
    uint32_t width; // 图像宽
    uint32_t height; // 图像高
    uint32_t stride; // 图像步长
    uint64_t timestamp; //时间戳
};

struct CaptureInfo
{
    uint8_t orientation; // 旋转角度：0不旋转，1旋转90°，2旋转180°，3旋转270°
    GpuFrameInfo info;
};

#endif // FRAME_COMMON_H
```



frameProducer.h

```c++
#ifndef FRAME_PRODUCER_H
#define FRAME_PRODUCER_H

#include <mutex>
#include "GpuFrameMock/FrameCommon.h"

class FrameProducer
{
    virtua ~FrameProducer()；
    int GetFrameGpuData(uint8_t*&pFrameData, size_t& len);
    int GetDeviceFrameInfo(CaptureInfo& frameInfo);
    void DestroyDevice();
    void InitDevice();
private:
    uint32_t m_width = 720;
    uint32_t m_height = 1280;
    void* pdata = nullptr;
    FILE* fin = nullptr;
    FILE* fout = nullptr;
};

#endif // FRAME_PRODUCER_H
```



gpuHostFrame.h

```c++
#ifndef GPU_HOST_FRAME_H
#define GPU_HOST_FRAME_H

#include <mutex>
#include <vector>
#include "GpuFrame.h"
#include "FrameProducer.h"

class GpuHostFrame : public FrameProducer, public GpuFrame
{
public:
	~GpuHostFrame();
	int GetFrameInfo(void* pHandler, CaptureInfo& FrameInof, vector<uint8_t*>& pFrame, size_t& len)
	int InitFrameChan(void* pHandler);
	void* DestroyFrameChn(void* pHandler);
};

#endif //GPU_HOST_FRAME_H

```



