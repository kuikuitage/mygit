cd /home/gw/opensource/quiche-master;./build.sh;
cd -;

cp /home/gw/opensource/quiche-master/target/release/build/quiche-89926a740859abda/out/build/libssl.a /home/gw/opensource/demo/libs/libssl.a
cp /home/gw/opensource/quiche-master/target/release/build/quiche-89926a740859abda/out/build/libcrypto.a /home/gw/opensource/demo/libs/libcrypto.a
cp /home/gw/opensource/quiche-master/target/release/libquiche.a /home/gw/opensource/demo/libs/libquiche.a
cp /home/gw/opensource/quiche-master/target/release/libquiche.so /home/gw/opensource/demo/src/libquiche.so

cc client.c -o client  -I../include -L../home/gw/opensource/quiche-master/target/release -L../libs   -lquiche -lcrypto -lssl -lev -lpthread  -ldl
cc server.c -o server  -I../include -L../home/gw/opensource/quiche-master/target/release -L../libs  -lquiche -lcrypto -lssl -lev  -lpthread -ldl
