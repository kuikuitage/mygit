#!/bin/bash
if [ $1 == "client" ]; then
	./client 127.0.0.1 443
elif [ $1 == "server" ]; then
	./server 127.0.0.1 443
fi

